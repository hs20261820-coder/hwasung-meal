"""화성고 급식 자동 업데이트 스크립트.
나이스 교육정보 개방포털(open.neis.go.kr) 급식 API에서 식단을 가져와
meals.json(앱용)과 meals.ics(캘린더 구독용)를 만든다.
GitHub Actions가 하루 두 번 실행한다.
"""
import datetime as dt
import json
import os
import re
import sys
import urllib.parse
import urllib.request

API = "https://open.neis.go.kr/hub/"
KEY = os.environ.get("NEIS_KEY", "")  # 없어도 동작(하루 단위 조회라 샘플 한도 5건 이내)
SCHOOL_NAME = os.environ.get("SCHOOL_NAME", "화성고등학교")
OFFICE = os.environ.get("OFFICE_CODE", "J10")  # 경기도교육청
SCHOOL_CODE = os.environ.get("SCHOOL_CODE", "")
KST = dt.timezone(dt.timedelta(hours=9))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORDER = {"조식": 0, "중식": 1, "석식": 2}


def call(service, **params):
    q = {"Type": "json", "pIndex": 1, "pSize": 5, **params}
    if KEY:
        q["KEY"] = KEY
    url = API + service + "?" + urllib.parse.urlencode(q)
    req = urllib.request.Request(url, headers={"User-Agent": "hwasung-meal/1.0"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read().decode("utf-8"))
    if service not in data:
        return []  # INFO-200: 데이터 없음
    return data[service][1]["row"]


def find_school():
    if SCHOOL_CODE:
        return SCHOOL_CODE
    rows = call("schoolInfo", ATPT_OFCDC_SC_CODE=OFFICE, SCHUL_NM=SCHOOL_NAME)
    rows = [r for r in rows if r["SCHUL_NM"] == SCHOOL_NAME]
    if not rows:
        sys.exit(f"학교를 찾지 못함: {SCHOOL_NAME}")
    return rows[0]["SD_SCHUL_CODE"]


def parse_dish(s):
    s = re.sub(r"<[^>]+>", "", s).strip()
    m = re.match(r"^(.*?)\s*\(?([\d.]+)\)?\.?$", s)
    if m and re.search(r"\d", m.group(2)):
        name, nums = m.group(1), m.group(2)
    else:
        name, nums = s, ""
    return [name.strip(" *"), [int(n) for n in nums.split(".") if n.isdigit()]]


def fetch_days(code, start, n):
    days = {}
    for i in range(n):
        d = start + dt.timedelta(days=i)
        rows = call("mealServiceDietInfo", ATPT_OFCDC_SC_CODE=OFFICE,
                    SD_SCHUL_CODE=code, MLSV_YMD=d.strftime("%Y%m%d"))
        meals = {}
        for r in sorted(rows, key=lambda r: ORDER.get(r["MMEAL_SC_NM"], 9)):
            kcal = re.findall(r"[\d.]+", r.get("CAL_INFO", "")) or ["0"]
            meals[r["MMEAL_SC_NM"]] = {
                "kcal": float(kcal[0]),
                "dishes": [parse_dish(x) for x in r["DDISH_NM"].split("<br/>") if x.strip()],
            }
        if meals:
            days[d.isoformat()] = meals
    return days


def esc(s):
    return s.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")


def fold(line):
    b = line.encode("utf-8")
    out, cur = [], b""
    for ch in line:
        c = ch.encode("utf-8")
        if len(cur) + len(c) > 73:
            out.append(cur.decode("utf-8"))
            cur = b" "
        cur += c
    out.append(cur.decode("utf-8"))
    return "\r\n".join(out)


def make_ics(days, now):
    L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//hwasung-meal//KO", "CALSCALE:GREGORIAN",
         "METHOD:PUBLISH", f"X-WR-CALNAME:{SCHOOL_NAME} 급식", "X-WR-TIMEZONE:Asia/Seoul",
         "REFRESH-INTERVAL;VALUE=DURATION:PT6H", "X-PUBLISHED-TTL:PT6H"]
    stamp = now.astimezone(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for day, meals in sorted(days.items()):
        d = dt.date.fromisoformat(day)
        start = dt.datetime(d.year, d.month, d.day, 7, 0, tzinfo=KST).astimezone(dt.timezone.utc)
        end = start + dt.timedelta(minutes=10)
        lunch = meals.get("중식") or next(iter(meals.values()))
        main = [x[0] for x in lunch["dishes"][1:3]]
        title = "🍱 급식 | 점심 " + ", ".join(main)
        desc = "\n\n".join(f"[{k}] " + ", ".join(x[0] for x in v["dishes"]) for k, v in meals.items())
        L += ["BEGIN:VEVENT", f"UID:hwasung-meal-{day}@github", f"DTSTAMP:{stamp}",
              f"DTSTART:{start:%Y%m%dT%H%M%SZ}", f"DTEND:{end:%Y%m%dT%H%M%SZ}",
              fold(f"SUMMARY:{esc(title)}"), fold(f"DESCRIPTION:{esc(desc)}"),
              "BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:오늘 급식", "TRIGGER:PT0M", "END:VALARM",
              "END:VEVENT"]
    L.append("END:VCALENDAR")
    return "\r\n".join(L) + "\r\n"


def main():
    now = dt.datetime.now(KST)
    code = find_school()
    start = now.date() - dt.timedelta(days=7)
    new = fetch_days(code, start, 45)  # 지난 1주 ~ 앞으로 5주

    path = os.path.join(ROOT, "meals.json")
    try:
        old = json.load(open(path, encoding="utf-8")).get("days", {})
    except Exception:
        old = {}
    keep_from = (now.date() - dt.timedelta(days=14)).isoformat()
    days = {k: v for k, v in old.items() if k >= keep_from}
    days.update(new)

    if {k: old.get(k) for k in days} == days and len(old) == len(days):
        print("변경 없음")
        return
    out = {"school": SCHOOL_NAME, "updated": now.isoformat(timespec="minutes"),
           "source": "나이스 교육정보 개방포털", "days": dict(sorted(days.items()))}
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    with open(os.path.join(ROOT, "meals.ics"), "w", encoding="utf-8", newline="") as f:
        f.write(make_ics(days, now))
    print(f"업데이트: {len(new)}일 새로 받음, 총 {len(days)}일")


if __name__ == "__main__":
    main()
