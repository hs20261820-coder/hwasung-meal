# 🍱 화성고 급식 앱

인터넷이 될 때 화성고 식단을 알아서 받아두고, 와이파이가 없을 때도 볼 수 있는 앱이에요.
아이폰과 갤럭시에서 모두 쓸 수 있어요. 주소 하나만 친구들에게 한 번 알려주면, 각자 홈 화면에 설치해서 계속 쓸 수 있어요.

- 식단: 나이스 교육정보 개방포털에서 하루 두 번(새벽 5시, 오후 5시) 자동으로 받아요.
- 오프라인: 앱을 한 번 열어두면, 그 뒤로는 인터넷 없이도 마지막으로 받은 식단이 보여요.
- 알림: 캘린더에 구독하면 매일 아침 7시에 그날 급식 알림이 와요. 오프라인에서도 울려요.

## 처음 한 번만 하는 설정 (약 10분, 컴퓨터에서)

1. **GitHub 가입**: https://github.com 에서 무료 계정을 만들어요.
2. **저장소 만들기**: 오른쪽 위 `+` → `New repository`
   - Repository name: `hwasung-meal`
   - **Public** 선택 → `Create repository`
3. **파일 올리기**: 새 저장소 화면에서 `uploading an existing file` 클릭 →
   압축을 푼 `hwasung-meal` 폴더 **안의 내용 전부**(`.github` 폴더 포함)를 끌어다 놓고 → `Commit changes`
   - Mac에서 `.github` 폴더가 안 보이면 Finder에서 `Cmd + Shift + .` 을 누르면 보여요.
4. **앱 주소 켜기**: `Settings` → 왼쪽 `Pages` → Branch를 `main` / `/(root)` 로 두고 `Save`
5. **자동 업데이트 켜기**: `Settings` → `Actions` → `General` → 맨 아래 *Workflow permissions* 에서
   `Read and write permissions` 선택 → `Save`
6. **첫 업데이트 실행**: 위쪽 `Actions` 탭 → `급식 업데이트` → `Run workflow`
   (초록색 체크가 뜨면 성공이에요.)

몇 분 뒤 앱 주소가 생겨요: **`https://<내 GitHub 아이디>.github.io/hwasung-meal/`**
이 주소를 아들과 친구들에게 **한 번만** 보내주면 돼요.

## 친구들이 할 일 (한 번만)

- **아이폰**: Safari로 주소 열기 → 공유 버튼(□↑) → **홈 화면에 추가**
- **갤럭시**: 삼성 인터넷 또는 크롬으로 열기 → 메뉴 → **홈 화면에 추가 / 앱 설치**
- (선택) 앱 안의 **⏰ 매일 아침 7시 알림 받기**에서 캘린더 구독

## 참고

- 식단이 안 바뀌면 `Actions` 탭에서 실패(빨간 X)가 있는지 확인해 보세요.
- 나이스 인증키(무료)를 받으면 더 안정적이에요: https://open.neis.go.kr → 인증키 신청 →
  저장소 `Settings` → `Secrets and variables` → `Actions` → `New repository secret`,
  이름 `NEIS_KEY`, 값에 인증키 입력. (없어도 동작해요.)
- GitHub는 60일 동안 저장소에 변화가 없으면 자동 실행을 멈출 수 있어요. 이 앱은 식단이 바뀔 때마다 저장소가 갱신돼서, 학기 중에는 보통 멈추지 않아요. 방학 뒤에 업데이트가 안 되면 `Actions` 탭에서 다시 켜주세요.
